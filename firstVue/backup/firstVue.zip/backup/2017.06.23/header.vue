<template lang="html">
  <div>
  </div>
</template>
<script lang="babel">
  export default{
    data () {
      return {}
    },
    components: {}
  }
</script>
<style lang="scss">

</style>
