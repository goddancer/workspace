<template lang="html">
  <div class="header">
    我是头部
  </div>
</template>
<script>
  export default {
    data () {
      return {}
    },
    components: {}
  }
</script>
<style>

</style>
