<template>
  <div id="app">
    <v-header></v-header>
    <div class="tab border-1px">
      <div class="tab-item">商品</div>
      <div class="tab-item">评价</div>
      <div class="tab-item">商家</div>
    </div>
    <div class="content">
      i am content!
    </div>
  </div>
</template>

<script>
  import header from './components/header/header.vue'
  export default{
    components: {
      'v-header': header
    }
  }
</script>

<style lang="scss" rel="stylesheet/scss">
  @import "../static/css/reset.css";
  @import "./common/css/mixin.scss";
  #app{
    .tab{
      width:100%;
      display: flex;
      height:40px;
      line-height:40px;
      @include border-1px(rgba(7,12,21,0.1));/*mixin 混合样式*/
      .tab-item{
        flex: 1;
        text-align: center;
      }
    }
  }
</style>
