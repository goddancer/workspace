<template>
  <div>i am ratings!</div>
</template>

<script>
    export default {}
</script>

<style lang="scss" rel="stylesheet/scss">

</style>
