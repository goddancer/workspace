<template>
  <div>i am seller!</div>
</template>

<script>
    export default {}
</script>

<style lang="scss" rel="stylesheet/scss">

</style>
