<template>
  <div>i am goods!</div>
</template>

<script>
    export default {}
</script>

<style lang="scss" rel="stylesheet/scss">

</style>
